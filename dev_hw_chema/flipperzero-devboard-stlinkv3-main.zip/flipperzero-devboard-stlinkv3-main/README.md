# Devboard for Flipper Zero based on ST-Link V3

Altium project sources

![Devboard for Flipper Zero based on ST-Link V3](https://cdn.flipperzero.one/devboard-stlinkv3.png)

## Files

`library.IntLib` — Altium components library